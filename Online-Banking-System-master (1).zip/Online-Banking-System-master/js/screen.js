function set_dimen()
{
	document.getElementById("wrap").style.width=(window.screen.availWidth)-1+"px;"
	document.getElementById("wrap").style.minWidth=(window.screen.availWidth)-1+"px;"
	document.getElementById("wrap").style.height=window.screen.availHeight+"px;"
	document.getElementById("wrap").style.minHeight=window.screen.availHeight+"px;"
}

